"use strict";

process.on("uncaughtException", (err) => {
  console.error("[CRASH] Uncaught exception:", err);
});
process.on("unhandledRejection", (reason) => {
  console.error("[CRASH] Unhandled rejection:", reason);
});

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
const { GoogleGenAI } = require("@google/genai");
const Stripe = require("stripe");

// ── ENV ────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "svardirekt-secret-change-me";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || "";
const STRIPE_PRICE_ID = process.env.STRIPE_PRICE_ID || "";
const OWNER_EMAIL = "charteks1@gmail.com";
const AI_DAILY_LIMIT = 10;
const FREE_LETTER_LIMIT = 3;

// ── JSON FILE STORAGE (no native modules needed) ───────────────────
const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const FILES = {
  users: path.join(DATA_DIR, "users.json"),
  devices: path.join(DATA_DIR, "devices.json"),
  usage: path.join(DATA_DIR, "usage.json"),
};

function readDB(file) {
  try {
    if (!fs.existsSync(file)) return {};
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return {};
  }
}

function writeDB(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

// ── DB HELPERS ─────────────────────────────────────────────────────
function getUsers() { return readDB(FILES.users); }
function saveUsers(u) { writeDB(FILES.users, u); }
function getDevices() { return readDB(FILES.devices); }
function saveDevices(d) { writeDB(FILES.devices, d); }
function getUsage() { return readDB(FILES.usage); }
function saveUsage(u) { writeDB(FILES.usage, u); }

function getUserById(id) {
  const users = getUsers();
  return users[id] || null;
}

function getUserByEmail(email) {
  const users = getUsers();
  return Object.values(users).find((u) => u.email === email.toLowerCase().trim()) || null;
}

function saveUser(user) {
  const users = getUsers();
  users[user.id] = user;
  saveUsers(users);
}

function deleteUser(id) {
  const users = getUsers();
  delete users[id];
  saveUsers(users);
}

// ── HELPERS ────────────────────────────────────────────────────────
function genId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "30d" });
}

function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

function toPublicUser(u) {
  const isOwner = u.email === OWNER_EMAIL;
  const isPremium = isOwner || !!u.is_premium;
  const freeUsed = u.free_letters_used || 0;
  const freeLettersRemaining = isPremium ? null : Math.max(0, FREE_LETTER_LIMIT - freeUsed);
  return {
    id: u.id,
    email: u.email,
    createdAt: u.created_at,
    isOwner,
    isPremium,
    subscriptionStatus: isOwner ? "active" : (u.subscription_status || "none"),
    trialEndsAt: null,
    currentPeriodEnd: u.current_period_end || null,
    stripeCustomerId: u.stripe_customer_id || null,
    freeLettersRemaining,
  };
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Autentisering krävs." });
  try {
    req.user = verifyToken(token);
    next();
  } catch {
    return res.status(401).json({ error: "Ogiltig token." });
  }
}

// ── STRIPE & AI ────────────────────────────────────────────────────
const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" }) : null;
const ai = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;

// ── APP ────────────────────────────────────────────────────────────
const app = express();
app.use(cors({ origin: "*" }));
app.use("/api/subscription/webhook", express.raw({ type: "application/json" }));
app.use(express.json());

// ── HEALTH ─────────────────────────────────────────────────────────
app.get("/api/test", (_req, res) => res.json({ ok: true, ts: Date.now() }));
app.get("/healthz", (_req, res) => res.json({ status: "ok" }));

// ── AUTH ───────────────────────────────────────────────────────────
app.post("/api/auth/register", async (req, res) => {
  try {
    const { email, password, deviceId } = req.body || {};
    if (!email?.trim() || !password?.trim())
      return res.status(400).json({ error: "E-post och lösenord krävs." });
    if (password.length < 6)
      return res.status(400).json({ error: "Lösenordet måste vara minst 6 tecken." });

    if (getUserByEmail(email))
      return res.status(409).json({ error: "E-postadressen används redan." });

    // Device abuse check
    let startFreeLetters = FREE_LETTER_LIMIT;
    if (deviceId) {
      const devices = getDevices();
      if (devices[deviceId]) {
        startFreeLetters = 0;
        devices[deviceId].account_count = (devices[deviceId].account_count || 1) + 1;
      } else {
        devices[deviceId] = { first_registered: Date.now(), account_count: 1 };
      }
      saveDevices(devices);
    }

    const hash = await bcrypt.hash(password, 10);
    const id = genId();
    const user = {
      id,
      email: email.toLowerCase().trim(),
      password_hash: hash,
      created_at: Date.now(),
      device_id: deviceId || null,
      is_premium: 0,
      subscription_status: "none",
      current_period_end: null,
      stripe_customer_id: null,
      free_letters_used: FREE_LETTER_LIMIT - startFreeLetters,
    };
    saveUser(user);

    const token = signToken({ sub: id, email: user.email });
    return res.json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/register]", err);
    return res.status(500).json({ error: "Ett fel uppstod. Försök igen." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email?.trim() || !password?.trim())
      return res.status(400).json({ error: "E-post och lösenord krävs." });

    const user = getUserByEmail(email);
    if (!user) return res.status(401).json({ error: "Fel e-post eller lösenord." });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Fel e-post eller lösenord." });

    const token = signToken({ sub: user.id, email: user.email });
    return res.json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/login]", err);
    return res.status(500).json({ error: "Ett fel uppstod. Försök igen." });
  }
});

app.get("/api/auth/me", authMiddleware, (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });
    return res.json({ user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/me]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

app.post("/api/auth/change-password", authMiddleware, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body || {};
    if (!oldPassword || !newPassword)
      return res.status(400).json({ error: "Gamla och nya lösenordet krävs." });
    if (newPassword.length < 6)
      return res.status(400).json({ error: "Nytt lösenord måste vara minst 6 tecken." });

    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    const ok = await bcrypt.compare(oldPassword, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Fel gammalt lösenord." });

    user.password_hash = await bcrypt.hash(newPassword, 10);
    saveUser(user);
    return res.json({ ok: true });
  } catch (err) {
    console.error("[auth/change-password]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

app.delete("/api/auth/account", authMiddleware, (req, res) => {
  try {
    deleteUser(req.user.sub);
    const usage = getUsage();
    delete usage[req.user.sub];
    saveUsage(usage);
    return res.json({ ok: true });
  } catch (err) {
    console.error("[auth/account DELETE]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

// ── SUBSCRIPTION ───────────────────────────────────────────────────
app.post("/api/subscription/checkout", authMiddleware, async (req, res) => {
  try {
    if (!stripe || !STRIPE_PRICE_ID)
      return res.status(503).json({ error: "Betalningar är inte konfigurerade." });

    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    const { successUrl, cancelUrl } = req.body || {};

    let customerId = user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({ email: user.email });
      customerId = customer.id;
      user.stripe_customer_id = customerId;
      saveUser(user);
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: "subscription",
      line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
      success_url: successUrl || "https://svardirekt.site",
      cancel_url: cancelUrl || "https://svardirekt.site",
    });

    return res.json({ url: session.url, sessionId: session.id });
  } catch (err) {
    console.error("[subscription/checkout]", err);
    return res.status(500).json({ error: "Kunde inte skapa betalningssession." });
  }
});

app.post("/api/subscription/portal", authMiddleware, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ error: "Betalningar är inte konfigurerade." });
    const user = getUserById(req.user.sub);
    if (!user?.stripe_customer_id)
      return res.status(400).json({ error: "Ingen prenumeration hittades." });

    const { returnUrl } = req.body || {};
    const session = await stripe.billingPortal.sessions.create({
      customer: user.stripe_customer_id,
      return_url: returnUrl || "https://svardirekt.site",
    });
    return res.json({ url: session.url });
  } catch (err) {
    console.error("[subscription/portal]", err);
    return res.status(500).json({ error: "Kunde inte öppna kundportalen." });
  }
});

app.post("/api/subscription/cancel", authMiddleware, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ error: "Betalningar är inte konfigurerade." });
    const user = getUserById(req.user.sub);
    if (!user?.stripe_customer_id)
      return res.status(400).json({ error: "Ingen prenumeration hittades." });

    const subs = await stripe.subscriptions.list({ customer: user.stripe_customer_id, limit: 1 });
    if (subs.data.length > 0) {
      await stripe.subscriptions.update(subs.data[0].id, { cancel_at_period_end: true });
    }
    user.subscription_status = "canceling";
    saveUser(user);
    return res.json({ user: toPublicUser(getUserById(user.id)) });
  } catch (err) {
    console.error("[subscription/cancel]", err);
    return res.status(500).json({ error: "Kunde inte avsluta prenumerationen." });
  }
});

app.post("/api/subscription/refresh", authMiddleware, async (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    if (stripe && user.stripe_customer_id) {
      const subs = await stripe.subscriptions.list({
        customer: user.stripe_customer_id, status: "all", limit: 1,
      });
      if (subs.data.length > 0) {
        const sub = subs.data[0];
        user.is_premium = (sub.status === "active" || sub.status === "trialing") ? 1 : 0;
        user.subscription_status = sub.status;
        user.current_period_end = sub.current_period_end * 1000;
        saveUser(user);
      }
    }
    return res.json({ user: toPublicUser(getUserById(user.id)) });
  } catch (err) {
    console.error("[subscription/refresh]", err);
    return res.status(500).json({ error: "Kunde inte uppdatera prenumerationen." });
  }
});

app.post("/api/subscription/webhook", (req, res) => {
  if (!stripe || !STRIPE_WEBHOOK_SECRET) return res.json({ received: true });
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook error: ${err.message}`);
  }
  try {
    const sub = event.data.object;
    const customerId = sub.customer;
    if (!customerId) return res.json({ received: true });

    const users = getUsers();
    const user = Object.values(users).find((u) => u.stripe_customer_id === customerId);
    if (!user) return res.json({ received: true });

    if (["customer.subscription.updated", "customer.subscription.created"].includes(event.type)) {
      user.is_premium = (sub.status === "active" || sub.status === "trialing") ? 1 : 0;
      user.subscription_status = sub.status;
      user.current_period_end = (sub.current_period_end || 0) * 1000;
      saveUser(user);
    } else if (event.type === "customer.subscription.deleted") {
      user.is_premium = 0;
      user.subscription_status = "canceled";
      user.current_period_end = null;
      saveUser(user);
    }
  } catch (err) {
    console.error("[webhook]", err);
  }
  return res.json({ received: true });
});

// ── AI ─────────────────────────────────────────────────────────────
app.post("/api/ai/ask", authMiddleware, async (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(401).json({ error: "Inte autentiserad." });

    const isOwner = user.email === OWNER_EMAIL;
    const isPremium = isOwner || !!user.is_premium;

    if (!isPremium) {
      const freeUsed = user.free_letters_used || 0;
      if (freeUsed >= FREE_LETTER_LIMIT) {
        return res.status(402).json({
          error: `Du har använt dina ${FREE_LETTER_LIMIT} gratisbrev. Prenumerera för obegränsad åtkomst.`,
          code: "PREMIUM_REQUIRED",
        });
      }
    } else if (!isOwner) {
      const today = todayStr();
      const usage = getUsage();
      const dayCount = (usage[user.id] && usage[user.id][today]) || 0;
      if (dayCount >= AI_DAILY_LIMIT) {
        return res.status(429).json({
          error: `Du har använt alla ${AI_DAILY_LIMIT} genereringar idag — återställs imorgon.`,
        });
      }
    }

    const { message } = req.body || {};
    if (!message?.trim()) return res.status(400).json({ error: "Meddelande saknas." });
    if (!ai) return res.status(503).json({ error: "AI-tjänsten är inte konfigurerad." });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: message }] }],
      config: { maxOutputTokens: 1500, temperature: 0.3 },
    });

    const reply = response.text?.trim();
    if (!reply) return res.status(500).json({ error: "Inget svar från AI. Försök igen." });

    // Update counters
    if (!isOwner) {
      if (isPremium) {
        const today = todayStr();
        const usage = getUsage();
        if (!usage[user.id]) usage[user.id] = {};
        usage[user.id][today] = (usage[user.id][today] || 0) + 1;
        saveUsage(usage);
        const newCount = usage[user.id][today];
        return res.json({ reply, remaining: Math.max(0, AI_DAILY_LIMIT - newCount) });
      } else {
        const newUsed = (user.free_letters_used || 0) + 1;
        user.free_letters_used = newUsed;
        saveUser(user);
        return res.json({ reply, remaining: Math.max(0, FREE_LETTER_LIMIT - newUsed) });
      }
    }

    return res.json({ reply, remaining: 999 });
  } catch (err) {
    console.error("[ai/ask]", err);
    return res.status(503).json({ error: "AI-tjänsten är tillfälligt otillgänglig. Försök igen senare." });
  }
});

// ── START ──────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`[Svar Direkt] Server running on port ${PORT}`);
  console.log(`[Svar Direkt] Data directory: ${DATA_DIR}`);
  console.log(`[Svar Direkt] Free letters: ${FREE_LETTER_LIMIT} | Premium daily: ${AI_DAILY_LIMIT}`);
  console.log(`[Svar Direkt] Gemini: ${ai ? "OK" : "NOT CONFIGURED"}`);
  console.log(`[Svar Direkt] Stripe: ${stripe ? "OK" : "NOT CONFIGURED"}`);
});
