import { describe, it, expect } from 'vitest';
import { categories } from '../data/scenarios';

describe('New Templates (50 added)', () => {
  it('should have 10 templates in each category', () => {
    categories.forEach((category) => {
      expect(category.scenarios.length).toBeGreaterThanOrEqual(10);
    });
  });

  it('should have at least 100 total templates', () => {
    const totalTemplates = categories.reduce((sum, cat) => sum + cat.scenarios.length, 0);
    expect(totalTemplates).toBeGreaterThanOrEqual(100);
  });

  it('Skatteverket should have templates up to skat_10', () => {
    const skatCategory = categories.find(c => c.id === 'skatteverket');
    expect(skatCategory).toBeDefined();
    const maxId = Math.max(...skatCategory!.scenarios.map(s => parseInt(s.id.split('_')[1])));
    expect(maxId).toBeGreaterThanOrEqual(10);
  });

  it('Försäkringskassan should have templates up to fk_10', () => {
    const fkCategory = categories.find(c => c.id === 'forsakringskassan');
    expect(fkCategory).toBeDefined();
    const maxId = Math.max(...fkCategory!.scenarios.map(s => parseInt(s.id.split('_')[1])));
    expect(maxId).toBeGreaterThanOrEqual(10);
  });

  it('Migrationsverket should have templates up to mv_10', () => {
    const mvCategory = categories.find(c => c.id === 'migrationsverket');
    expect(mvCategory).toBeDefined();
    const maxId = Math.max(...mvCategory!.scenarios.map(s => parseInt(s.id.split('_')[1])));
    expect(maxId).toBeGreaterThanOrEqual(10);
  });

  it('all templates should have placeholders', () => {
    categories.forEach((category) => {
      category.scenarios.forEach((scenario) => {
        expect(scenario.placeholders.length).toBeGreaterThan(0);
        scenario.placeholders.forEach((ph) => {
          expect(ph.key).toBeDefined();
          expect(ph.label).toBeDefined();
        });
      });
    });
  });

  it('new templates should have Swedish text', () => {
    const newTemplateIds = ['skat_06', 'fk_06', 'mv_06', 'arb_06', 'soc_06', 'pol_06', 'dom_06', 'bov_06'];
    
    categories.forEach((category) => {
      category.scenarios.forEach((scenario) => {
        if (newTemplateIds.includes(scenario.id)) {
          expect(scenario.template).toMatch(/[åäöÅÄÖ]/);
          expect(scenario.template).toContain('Hej');
        }
      });
    });
  });

  it('new templates should be properly formatted', () => {
    const newTemplateIds = ['ink_20', 'kfm_11', 'skat_06', 'fk_06', 'mv_06', 'arb_06', 'soc_06', 'pol_06', 'dom_06', 'bov_06'];
    
    categories.forEach((category) => {
      category.scenarios.forEach((scenario) => {
        if (newTemplateIds.includes(scenario.id)) {
          expect(scenario.title).toBeDefined();
          expect(scenario.title.length).toBeGreaterThan(0);
          expect(scenario.description).toBeDefined();
          expect(scenario.description.length).toBeGreaterThan(0);
          expect(scenario.template).toBeDefined();
          expect(scenario.template.length).toBeGreaterThan(0);
        }
      });
    });
  });
});
