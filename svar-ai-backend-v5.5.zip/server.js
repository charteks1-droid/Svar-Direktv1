"use strict";

process.on("uncaughtException", (err) => {
  console.error("[CRASH] Uncaught exception:", err);
});
process.on("unhandledRejection", (reason) => {
  console.error("[CRASH] Unhandled rejection:", reason);
});

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
const { GoogleGenAI } = require("@google/genai");
const Stripe = require("stripe");

// ── ENV ────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "svardirekt-secret-change-me";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || "";
const STRIPE_PRICE_ID = "price_1TSALxH5NBXFvwrpGkmsv4AS";
const OWNER_EMAIL = "charteks1@gmail.com";
const AI_DAILY_LIMIT = 10;
const FREE_LETTER_LIMIT = 3;

// ── JSON FILE STORAGE (no native modules needed) ───────────────────
const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const FILES = {
  users: path.join(DATA_DIR, "users.json"),
  devices: path.join(DATA_DIR, "devices.json"),
  usage: path.join(DATA_DIR, "usage.json"),
};

function readDB(file) {
  try {
    if (!fs.existsSync(file)) return {};
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return {};
  }
}

function writeDB(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

// ── DB HELPERS ─────────────────────────────────────────────────────
function getUsers() { return readDB(FILES.users); }
function saveUsers(u) { writeDB(FILES.users, u); }
function getDevices() { return readDB(FILES.devices); }
function saveDevices(d) { writeDB(FILES.devices, d); }
function getUsage() { return readDB(FILES.usage); }
function saveUsage(u) { writeDB(FILES.usage, u); }

function getUserById(id) {
  const users = getUsers();
  return users[id] || null;
}

function getUserByEmail(email) {
  const users = getUsers();
  return Object.values(users).find((u) => u.email === email.toLowerCase().trim()) || null;
}

function saveUser(user) {
  const users = getUsers();
  users[user.id] = user;
  saveUsers(users);
}

function deleteUser(id) {
  const users = getUsers();
  delete users[id];
  saveUsers(users);
}

// ── HELPERS ────────────────────────────────────────────────────────
function genId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "30d" });
}

function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

function toPublicUser(u) {
  const isOwner = u.email === OWNER_EMAIL;
  const isPremium = isOwner || !!u.is_premium;
  const freeUsed = u.free_letters_used || 0;
  const freeLettersRemaining = isPremium ? null : Math.max(0, FREE_LETTER_LIMIT - freeUsed);
  return {
    id: u.id,
    email: u.email,
    createdAt: u.created_at,
    isOwner,
    isPremium,
    subscriptionStatus: isOwner ? "active" : (u.subscription_status || "none"),
    trialEndsAt: null,
    currentPeriodEnd: u.current_period_end || null,
    stripeCustomerId: u.stripe_customer_id || null,
    freeLettersRemaining,
  };
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Autentisering krävs." });
  try {
    req.user = verifyToken(token);
    next();
  } catch {
    return res.status(401).json({ error: "Ogiltig token." });
  }
}

// ── STRIPE & AI ────────────────────────────────────────────────────
const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" }) : null;
const ai = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;

// ── APP ────────────────────────────────────────────────────────────
const app = express();
app.use(cors({ origin: "*" }));
app.use("/api/subscription/webhook", express.raw({ type: "application/json" }));
app.use(express.json());

// ── HEALTH ─────────────────────────────────────────────────────────
app.get("/api/test", (_req, res) => res.json({ ok: true, ts: Date.now() }));
app.get("/healthz", (_req, res) => res.json({ status: "ok" }));

// ── AUTH ───────────────────────────────────────────────────────────
app.post("/api/auth/register", async (req, res) => {
  try {
    const { email, password, deviceId } = req.body || {};
    if (!email?.trim() || !password?.trim())
      return res.status(400).json({ error: "E-post och lösenord krävs." });
    if (password.length < 6)
      return res.status(400).json({ error: "Lösenordet måste vara minst 6 tecken." });

    if (getUserByEmail(email))
      return res.status(409).json({ error: "E-postadressen används redan." });

    // Device abuse check
    let startFreeLetters = FREE_LETTER_LIMIT;
    if (deviceId) {
      const devices = getDevices();
      if (devices[deviceId]) {
        startFreeLetters = 0;
        devices[deviceId].account_count = (devices[deviceId].account_count || 1) + 1;
      } else {
        devices[deviceId] = { first_registered: Date.now(), account_count: 1 };
      }
      saveDevices(devices);
    }

    const hash = await bcrypt.hash(password, 10);
    const id = genId();
    const user = {
      id,
      email: email.toLowerCase().trim(),
      password_hash: hash,
      created_at: Date.now(),
      device_id: deviceId || null,
      is_premium: 0,
      subscription_status: "none",
      current_period_end: null,
      stripe_customer_id: null,
      free_letters_used: FREE_LETTER_LIMIT - startFreeLetters,
    };
    saveUser(user);

    const token = signToken({ sub: id, email: user.email });
    return res.json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/register]", err);
    return res.status(500).json({ error: "Ett fel uppstod. Försök igen." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email?.trim() || !password?.trim())
      return res.status(400).json({ error: "E-post och lösenord krävs." });

    const user = getUserByEmail(email);
    if (!user) return res.status(401).json({ error: "Fel e-post eller lösenord." });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Fel e-post eller lösenord." });

    const token = signToken({ sub: user.id, email: user.email });
    return res.json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/login]", err);
    return res.status(500).json({ error: "Ett fel uppstod. Försök igen." });
  }
});

app.get("/api/auth/me", authMiddleware, (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });
    return res.json({ user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/me]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

app.post("/api/auth/change-password", authMiddleware, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body || {};
    if (!oldPassword || !newPassword)
      return res.status(400).json({ error: "Gamla och nya lösenordet krävs." });
    if (newPassword.length < 6)
      return res.status(400).json({ error: "Nytt lösenord måste vara minst 6 tecken." });

    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    const ok = await bcrypt.compare(oldPassword, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Fel gammalt lösenord." });

    user.password_hash = await bcrypt.hash(newPassword, 10);
    saveUser(user);
    return res.json({ ok: true });
  } catch (err) {
    console.error("[auth/change-password]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

app.delete("/api/auth/account", authMiddleware, (req, res) => {
  try {
    deleteUser(req.user.sub);
    const usage = getUsage();
    delete usage[req.user.sub];
    saveUsage(usage);
    return res.json({ ok: true });
  } catch (err) {
    console.error("[auth/account DELETE]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

// ── SUBSCRIPTION ───────────────────────────────────────────────────
app.post("/api/subscription/checkout", authMiddleware, async (req, res) => {
  try {
    if (!stripe || !STRIPE_PRICE_ID)
      return res.status(503).json({ error: "Betalningar är inte konfigurerade." });

    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    const { successUrl, cancelUrl } = req.body || {};

    let customerId = user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({ email: user.email });
      customerId = customer.id;
      user.stripe_customer_id = customerId;
      saveUser(user);
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: "subscription",
      line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
      success_url: successUrl || "https://svardirekt.site",
      cancel_url: cancelUrl || "https://svardirekt.site",
    });

    return res.json({ url: session.url, sessionId: session.id });
  } catch (err) {
    console.error("[subscription/checkout]", err);
    return res.status(500).json({ error: "Kunde inte skapa betalningssession.", detail: err?.message || String(err) });
  }
});

app.post("/api/subscription/portal", authMiddleware, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ error: "Betalningar är inte konfigurerade." });
    const user = getUserById(req.user.sub);
    if (!user?.stripe_customer_id)
      return res.status(400).json({ error: "Ingen prenumeration hittades." });

    const { returnUrl } = req.body || {};
    const session = await stripe.billingPortal.sessions.create({
      customer: user.stripe_customer_id,
      return_url: returnUrl || "https://svardirekt.site",
    });
    return res.json({ url: session.url });
  } catch (err) {
    console.error("[subscription/portal]", err);
    return res.status(500).json({ error: "Kunde inte öppna kundportalen." });
  }
});

app.post("/api/subscription/cancel", authMiddleware, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ error: "Betalningar är inte konfigurerade." });
    const user = getUserById(req.user.sub);
    if (!user?.stripe_customer_id)
      return res.status(400).json({ error: "Ingen prenumeration hittades." });

    const subs = await stripe.subscriptions.list({ customer: user.stripe_customer_id, limit: 1 });
    if (subs.data.length > 0) {
      await stripe.subscriptions.update(subs.data[0].id, { cancel_at_period_end: true });
    }
    user.subscription_status = "canceling";
    saveUser(user);
    return res.json({ user: toPublicUser(getUserById(user.id)) });
  } catch (err) {
    console.error("[subscription/cancel]", err);
    return res.status(500).json({ error: "Kunde inte avsluta prenumerationen." });
  }
});

app.post("/api/subscription/refresh", authMiddleware, async (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    if (stripe && user.stripe_customer_id) {
      const subs = await stripe.subscriptions.list({
        customer: user.stripe_customer_id, status: "all", limit: 1,
      });
      if (subs.data.length > 0) {
        const sub = subs.data[0];
        user.is_premium = (sub.status === "active" || sub.status === "trialing") ? 1 : 0;
        user.subscription_status = sub.status;
        user.current_period_end = sub.current_period_end * 1000;
        saveUser(user);
      }
    }
    return res.json({ user: toPublicUser(getUserById(user.id)) });
  } catch (err) {
    console.error("[subscription/refresh]", err);
    return res.status(500).json({ error: "Kunde inte uppdatera prenumerationen." });
  }
});

app.post("/api/subscription/webhook", (req, res) => {
  if (!stripe || !STRIPE_WEBHOOK_SECRET) return res.json({ received: true });
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook error: ${err.message}`);
  }
  try {
    const sub = event.data.object;
    const customerId = sub.customer;
    if (!customerId) return res.json({ received: true });

    const users = getUsers();
    const user = Object.values(users).find((u) => u.stripe_customer_id === customerId);
    if (!user) return res.json({ received: true });

    if (["customer.subscription.updated", "customer.subscription.created"].includes(event.type)) {
      user.is_premium = (sub.status === "active" || sub.status === "trialing") ? 1 : 0;
      user.subscription_status = sub.status;
      user.current_period_end = (sub.current_period_end || 0) * 1000;
      saveUser(user);
    } else if (event.type === "customer.subscription.deleted") {
      user.is_premium = 0;
      user.subscription_status = "canceled";
      user.current_period_end = null;
      saveUser(user);
    }
  } catch (err) {
    console.error("[webhook]", err);
  }
  return res.json({ received: true });
});

// ── AI ─────────────────────────────────────────────────────────────
app.post("/api/ai/ask", authMiddleware, async (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(401).json({ error: "Inte autentiserad." });

    const isOwner = user.email === OWNER_EMAIL;
    const isPremium = isOwner || !!user.is_premium;

    if (!isPremium) {
      const freeUsed = user.free_letters_used || 0;
      if (freeUsed >= FREE_LETTER_LIMIT) {
        return res.status(402).json({
          error: `Du har använt dina ${FREE_LETTER_LIMIT} gratisbrev. Prenumerera för obegränsad åtkomst.`,
          code: "PREMIUM_REQUIRED",
        });
      }
    } else if (!isOwner) {
      const today = todayStr();
      const usage = getUsage();
      const dayCount = (usage[user.id] && usage[user.id][today]) || 0;
      if (dayCount >= AI_DAILY_LIMIT) {
        return res.status(429).json({
          error: `Du har använt alla ${AI_DAILY_LIMIT} genereringar idag — återställs imorgon.`,
        });
      }
    }

    const { message } = req.body || {};
    if (!message?.trim()) return res.status(400).json({ error: "Meddelande saknas." });
    if (!ai) return res.status(503).json({ error: "AI-tjänsten är inte konfigurerad." });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: message }] }],
      config: {
        maxOutputTokens: 1500,
        temperature: 0.3,
        systemInstruction: "Du är en svensk brevskrivningsassistent. Din enda uppgift är att skriva ETT formellt brev på svenska. Returnera ENBART brevtexten — ingen inledning, ingen förklaring, inga kommentarer, ingen engelsk text, ingen rubrik som 'Här är brevet'. Börja direkt med avsändarens namn eller brevets första rad. Skriv aldrig mer än ett brev. Skriv alltid på svenska.",
      },
    });

    const reply = response.text?.trim();
    if (!reply) return res.status(500).json({ error: "Inget svar från AI. Försök igen." });

    // Update counters
    if (!isOwner) {
      if (isPremium) {
        const today = todayStr();
        const usage = getUsage();
        if (!usage[user.id]) usage[user.id] = {};
        usage[user.id][today] = (usage[user.id][today] || 0) + 1;
        saveUsage(usage);
        const newCount = usage[user.id][today];
        return res.json({ reply, remaining: Math.max(0, AI_DAILY_LIMIT - newCount) });
      } else {
        const newUsed = (user.free_letters_used || 0) + 1;
        user.free_letters_used = newUsed;
        saveUser(user);
        return res.json({ reply, remaining: Math.max(0, FREE_LETTER_LIMIT - newUsed) });
      }
    }

    return res.json({ reply, remaining: 999 });
  } catch (err) {
    console.error("[ai/ask]", err);
    return res.status(503).json({ error: "AI-tjänsten är tillfälligt otillgänglig. Försök igen senare." });
  }
});

// ── FORUM ──────────────────────────────────────────────────────────
const FORUM_ADMIN_KEY = process.env.FORUM_ADMIN_KEY || "svar-admin-2026";
const FORUM_FILES = {
  threads: path.join(DATA_DIR, "forum_threads.json"),
  replies: path.join(DATA_DIR, "forum_replies.json"),
};
function getForumThreads() { try { return JSON.parse(fs.readFileSync(FORUM_FILES.threads,"utf8")); } catch { return []; } }
function saveForumThreads(d) { fs.writeFileSync(FORUM_FILES.threads, JSON.stringify(d,null,2)); }
function getForumReplies() { try { return JSON.parse(fs.readFileSync(FORUM_FILES.replies,"utf8")); } catch { return []; } }
function saveForumReplies(d) { fs.writeFileSync(FORUM_FILES.replies, JSON.stringify(d,null,2)); }

const FORUM_CATS = [
  { id:"kronofogden",      name:"Kronofogden",       icon:"⚖️",  desc:"Skulder, utmätning, betalningsföreläggande",   color:"#dc2626" },
  { id:"skatteverket",     name:"Skatteverket",       icon:"📋", desc:"Deklaration, skatt, folkbokföring",              color:"#0a7ea4" },
  { id:"forsakringskassan",name:"Försäkringskassan",  icon:"💙", desc:"Sjukpenning, föräldrapenning, a-kassa",          color:"#0984e3" },
  { id:"migrationsverket", name:"Migrationsverket",   icon:"🛂", desc:"Uppehållstillstånd, medborgarskap, visum",        color:"#6c5ce7" },
  { id:"arbetsformedlingen",name:"Arbetsförmedlingen",icon:"💼", desc:"Jobb, ersättning, åtgärder",                     color:"#d97706" },
];

app.get("/api/forum/categories", (req, res) => {
  const threads = getForumThreads();
  const cats = FORUM_CATS.map(c => {
    const catThreads = threads.filter(t => t.category === c.id && !t.is_hidden);
    const replies = getForumReplies();
    const totalReplies = catThreads.reduce((s, t) => s + replies.filter(r => r.thread_id === t.id && !r.is_hidden).length, 0);
    const unanswered = catThreads.filter(t => replies.filter(r => r.thread_id === t.id).length === 0).length;
    return { ...c, threads: catThreads.length, replies: totalReplies, unanswered };
  });
  res.json(cats);
});

app.get("/api/forum/threads", (req, res) => {
  const { category } = req.query;
  const threads = getForumThreads().filter(t => !t.is_hidden && (!category || t.category === category));
  const replies = getForumReplies();
  const result = threads.sort((a,b) => new Date(b.created_at)-new Date(a.created_at)).map(t => ({
    ...t,
    reply_count: replies.filter(r => r.thread_id === t.id && !r.is_hidden).length,
    body_preview: t.body.slice(0,120),
  }));
  res.json(result);
});

app.post("/api/forum/threads", (req, res) => {
  const { category, title, body, author_token } = req.body || {};
  if (!category || !title?.trim() || !body?.trim()) return res.status(400).json({ error: "Fält saknas" });
  if (title.trim().length < 10) return res.status(400).json({ error: "Titeln för kort" });
  if (body.trim().length < 20) return res.status(400).json({ error: "Frågan för kort" });
  const threads = getForumThreads();
  const id = Date.now();
  const thread = { id, category, title: title.trim(), body: body.trim(), author_token: author_token||"anon",
    display_name: "Anonym", is_solved: false, is_hidden: false, created_at: new Date().toISOString() };
  threads.push(thread);
  saveForumThreads(threads);
  res.json({ id });
});

app.get("/api/forum/threads/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const thread = getForumThreads().find(t => t.id === id && !t.is_hidden);
  if (!thread) return res.status(404).json({ error: "Tråden hittades inte" });
  const replies = getForumReplies().filter(r => r.thread_id === id && !r.is_hidden);
  res.json({ ...thread, reply_count: replies.length, replies });
});

app.post("/api/forum/threads/:id/replies", (req, res) => {
  const threadId = parseInt(req.params.id);
  const thread = getForumThreads().find(t => t.id === threadId && !t.is_hidden);
  if (!thread) return res.status(404).json({ error: "Tråden hittades inte" });
  const { body, author_token } = req.body || {};
  if (!body?.trim() || body.trim().length < 10) return res.status(400).json({ error: "Svaret för kort" });
  const replies = getForumReplies();
  const reply = { id: Date.now(), thread_id: threadId, body: body.trim(), author_token: author_token||"anon",
    display_name: "Anonym", helpful_count: 0, is_best_answer: false, is_hidden: false, created_at: new Date().toISOString() };
  replies.push(reply);
  saveForumReplies(replies);
  res.json({ id: reply.id });
});

app.post("/api/forum/replies/:id/helpful", (req, res) => {
  const id = parseInt(req.params.id);
  const replies = getForumReplies();
  const reply = replies.find(r => r.id === id);
  if (!reply) return res.status(404).json({ error: "Svar hittades inte" });
  reply.helpful_count = (reply.helpful_count || 0) + 1;
  saveForumReplies(replies);
  res.json({ ok: true });
});

app.get("/api/forum/admin/threads", (req, res) => {
  if (req.headers["x-admin-key"] !== FORUM_ADMIN_KEY) return res.status(403).json({ error: "Fel admin-nyckel" });
  const threads = getForumThreads();
  const replies = getForumReplies();
  res.json(threads.sort((a,b)=>new Date(b.created_at)-new Date(a.created_at)).map(t=>({
    ...t, reply_count: replies.filter(r=>r.thread_id===t.id).length, body_preview: t.body.slice(0,100)
  })));
});

app.patch("/api/forum/admin/threads/:id/hide", (req, res) => {
  if (req.headers["x-admin-key"] !== FORUM_ADMIN_KEY) return res.status(403).json({ error: "Fel admin-nyckel" });
  const id = parseInt(req.params.id);
  const threads = getForumThreads();
  const t = threads.find(t => t.id === id);
  if (!t) return res.status(404).json({ error: "Tråden hittades inte" });
  t.is_hidden = !t.is_hidden;
  saveForumThreads(threads);
  res.json({ ok: true, is_hidden: t.is_hidden });
});

app.delete("/api/forum/admin/threads/:id", (req, res) => {
  if (req.headers["x-admin-key"] !== FORUM_ADMIN_KEY) return res.status(403).json({ error: "Fel admin-nyckel" });
  const id = parseInt(req.params.id);
  const threads = getForumThreads().filter(t => t.id !== id);
  const replies = getForumReplies().filter(r => r.thread_id !== id);
  saveForumThreads(threads);
  saveForumReplies(replies);
  res.json({ ok: true });
});

// ── NEWS ────────────────────────────────────────────────────────────
const STATIC_NEWS = [
  { id:1, date:"2026-04-15", source:"Skatteverket", category:"skatteverket", title:"Nya regler för ROT- och RUT-avdrag 2026", summary:"Skatteverket har uppdaterat gränserna för ROT- och RUT-avdrag. Maxbeloppet för ROT höjs till 75 000 kr per person och år.", url:"https://www.skatteverket.se" },
  { id:2, date:"2026-04-01", source:"Försäkringskassan", category:"forsakringskassan", title:"Höjd SGI-gräns för föräldrapenning från 1 april", summary:"Sjukpenninggrundande inkomst höjs. Fler familjer kan nu få högre föräldrapenning baserat på den nya SGI-beräkningen.", url:"https://www.forsakringskassan.se" },
  { id:3, date:"2026-03-20", source:"Migrationsverket", category:"migrationsverket", title:"Förändrade handläggningstider för uppehållstillstånd", summary:"Migrationsverket meddelar att handläggningstider för arbetsuppehållstillstånd förväntas minska under 2026 efter ny digitalisering.", url:"https://www.migrationsverket.se" },
  { id:4, date:"2026-03-10", source:"Kronofogden", category:"kronofogden", title:"Ny möjlighet till skuldsanering för fler grupper", summary:"Från mars 2026 utvidgas möjligheten till skuldsanering. Fler personer med skulder kan ansöka om att få sina skulder sanerade.", url:"https://www.kronofogden.se" },
  { id:5, date:"2026-02-28", source:"Arbetsförmedlingen", category:"arbetsformedlingen", title:"Utökad matchningstjänst för nyanlända 2026", summary:"Arbetsförmedlingen lanserar utökad digital matchningstjänst som hjälper nyanlända hitta arbete snabbare.", url:"https://www.arbetsformedlingen.se" },
  { id:6, date:"2026-02-15", source:"Skatteverket", category:"skatteverket", title:"Ändrade regler för F-skatt och egenanställda", summary:"Skatteverket förtydligar reglerna för F-skatt. Egenanställda och frilansare berörs av de nya riktlinjerna från 2026.", url:"https://www.skatteverket.se" },
  { id:7, date:"2026-01-20", source:"Pensionsmyndigheten", category:"pensionsmyndigheten", title:"Pensioner höjs med 3,2% från januari 2026", summary:"Inkomstpensioner och tilläggspensioner höjs med 3,2 procent från och med januari 2026 på grund av prisbasbeloppsjustering.", url:"https://www.pensionsmyndigheten.se" },
];

app.get("/api/tools/news", (req, res) => {
  const { category } = req.query;
  const items = category ? STATIC_NEWS.filter(n => n.category === category) : STATIC_NEWS;
  res.json({ items, last_updated: "2026-04-15T10:00:00Z" });
});

// ── CALENDAR ────────────────────────────────────────────────────────
const ALL_DEADLINES = [
  { date:"2026-05-04", title:"Sista dag att lämna inkomstdeklaration (privatpersoner)", category:"skatteverket", desc:"Deklarera din inkomst för 2025 hos Skatteverket. Kan göras via app eller webben." },
  { date:"2026-05-06", title:"Skatteåterbetalning börjar (tidiga deklarationer)", category:"skatteverket", desc:"Om du deklarerade i april betalas eventuell skatteåterbäring ut runt detta datum." },
  { date:"2026-06-01", title:"Sista dag – Ansökan om bostadsbidrag (halvår)", category:"forsakringskassan", desc:"Ansök om bostadsbidrag för första halvåret 2026 hos Försäkringskassan." },
  { date:"2026-06-12", title:"Midsommar – myndigheter stänger", category:"skatteverket", desc:"Nationell helgdag. Alla myndigheter stängt 12-15 juni." },
  { date:"2026-08-17", title:"Deklaration för dödsbon", category:"skatteverket", desc:"Sista dag att lämna deklaration för dödsbon avseende inkomståret 2025." },
  { date:"2026-09-01", title:"Ansökan om skuldsanering – ny ansökningsperiod", category:"kronofogden", desc:"Ny ansökningsperiod öppnar för skuldsanering hos Kronofogden." },
  { date:"2026-09-15", title:"Kvarskatteinbetalning period 1", category:"skatteverket", desc:"Betala kvarskatt om du fått slutskattebesked med belopp att betala." },
  { date:"2026-10-01", title:"Föräldrapenning – anmälan för höst", category:"forsakringskassan", desc:"Sista dag att anmäla föräldraledighet för höst/vinter till Försäkringskassan." },
  { date:"2026-11-12", title:"Deklaration för handelsbolag", category:"skatteverket", desc:"Sista dag att lämna inkomstdeklaration för handelsbolag." },
  { date:"2026-12-01", title:"Arbetsgivardeklaration december", category:"skatteverket", desc:"Arbetsgivare ska lämna arbetsgivardeklaration för november." },
  { date:"2026-04-01", title:"Höjd föräldrapenning – ny SGI gäller", category:"forsakringskassan", desc:"Ny sjukpenninggrundande inkomst börjar gälla för föräldrapenning." },
  { date:"2026-03-31", title:"Kvarskatt period 2 – sista betalningsdag", category:"skatteverket", desc:"Sista dag att betala kvarskatt för andra perioden." },
];

app.get("/api/tools/calendar", (req, res) => {
  const today = new Date(); today.setHours(0,0,0,0);
  const upcoming = ALL_DEADLINES.filter(d => new Date(d.date) >= today).sort((a,b)=>new Date(a.date)-new Date(b.date));
  const past = ALL_DEADLINES.filter(d => new Date(d.date) < today).sort((a,b)=>new Date(b.date)-new Date(a.date));
  res.json({ upcoming, past });
});

// ── START ──────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`[Svar Direkt] Server running on port ${PORT}`);
  console.log(`[Svar Direkt] Data directory: ${DATA_DIR}`);
  console.log(`[Svar Direkt] Free letters: ${FREE_LETTER_LIMIT} | Premium daily: ${AI_DAILY_LIMIT}`);
  console.log(`[Svar Direkt] Gemini: ${ai ? "OK" : "NOT CONFIGURED"}`);
  console.log(`[Svar Direkt] Stripe: ${stripe ? "OK" : "NOT CONFIGURED"}`);
});
