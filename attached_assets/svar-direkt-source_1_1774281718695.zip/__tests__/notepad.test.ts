import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Mock AsyncStorage
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
    clear: vi.fn(),
  },
}));

const NOTEPAD_STORAGE_KEY = "svar_direkt_notepad";

interface NotepadData {
  noteText: string;
  fullName: string;
  personnummer: string;
}

describe("Notepad Feature", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it("should save notepad data to AsyncStorage", async () => {
    const testData: NotepadData = {
      noteText: "Test note content",
      fullName: "John Doe",
      personnummer: "123456-7890",
    };

    await AsyncStorage.setItem(NOTEPAD_STORAGE_KEY, JSON.stringify(testData));

    expect(AsyncStorage.setItem).toHaveBeenCalledWith(
      NOTEPAD_STORAGE_KEY,
      JSON.stringify(testData)
    );
  });

  it("should load notepad data from AsyncStorage", async () => {
    const testData: NotepadData = {
      noteText: "Test note content",
      fullName: "Jane Smith",
      personnummer: "987654-3210",
    };

    vi.mocked(AsyncStorage.getItem).mockResolvedValueOnce(JSON.stringify(testData));

    const result = await AsyncStorage.getItem(NOTEPAD_STORAGE_KEY);
    const parsedData = result ? JSON.parse(result) : null;

    expect(parsedData).toEqual(testData);
    expect(AsyncStorage.getItem).toHaveBeenCalledWith(NOTEPAD_STORAGE_KEY);
  });

  it("should handle empty notepad data", async () => {
    vi.mocked(AsyncStorage.getItem).mockResolvedValueOnce(null);

    const result = await AsyncStorage.getItem(NOTEPAD_STORAGE_KEY);

    expect(result).toBeNull();
  });

  it("should update notepad data correctly", async () => {
    const initialData: NotepadData = {
      noteText: "Initial note",
      fullName: "John Doe",
      personnummer: "123456-7890",
    };

    const updatedData: NotepadData = {
      noteText: "Updated note content with more text",
      fullName: "John Doe",
      personnummer: "123456-7890",
    };

    await AsyncStorage.setItem(NOTEPAD_STORAGE_KEY, JSON.stringify(initialData));
    await AsyncStorage.setItem(NOTEPAD_STORAGE_KEY, JSON.stringify(updatedData));

    expect(AsyncStorage.setItem).toHaveBeenCalledTimes(2);
    expect(AsyncStorage.setItem).toHaveBeenLastCalledWith(
      NOTEPAD_STORAGE_KEY,
      JSON.stringify(updatedData)
    );
  });

  it("should persist user profile data (fullName and personnummer)", async () => {
    const userData: NotepadData = {
      noteText: "Some note",
      fullName: "Anna Svensson",
      personnummer: "198512345678",
    };

    await AsyncStorage.setItem(NOTEPAD_STORAGE_KEY, JSON.stringify(userData));

    expect(AsyncStorage.setItem).toHaveBeenCalledWith(
      NOTEPAD_STORAGE_KEY,
      JSON.stringify(userData)
    );

    // Verify fullName and personnummer are saved
    const savedData = JSON.stringify(userData);
    expect(savedData).toContain("Anna Svensson");
    expect(savedData).toContain("198512345678");
  });

  it("should handle special characters in notepad text", async () => {
    const testData: NotepadData = {
      noteText: "Test with special chars: åäö, !@#$%^&*()",
      fullName: "Åsa Öberg",
      personnummer: "123456-7890",
    };

    await AsyncStorage.setItem(NOTEPAD_STORAGE_KEY, JSON.stringify(testData));

    expect(AsyncStorage.setItem).toHaveBeenCalledWith(
      NOTEPAD_STORAGE_KEY,
      JSON.stringify(testData)
    );
  });

  it("should clear all notepad data", async () => {
    await AsyncStorage.removeItem(NOTEPAD_STORAGE_KEY);

    expect(AsyncStorage.removeItem).toHaveBeenCalledWith(NOTEPAD_STORAGE_KEY);
  });
});
