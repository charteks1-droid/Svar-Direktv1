import { describe, it, expect } from "vitest";
import { categories } from "../data/scenarios";

describe("Scenarios Data", () => {
  it("should have exactly 10 categories", () => {
    expect(categories).toHaveLength(10);
  });

  it("should have Inkasso and Kronofogden categories", () => {
    const ids = categories.map((c) => c.id);
    expect(ids).toContain("inkasso");
    expect(ids).toContain("kronofogden");
  });

  it("all categories should have required fields", () => {
    for (const category of categories) {
      expect(category.id).toBeTruthy();
      expect(category.title).toBeTruthy();
      expect(category.subtitle).toBeTruthy();
      expect(category.icon).toBeTruthy();
      expect(category.scenarios.length).toBeGreaterThan(0);
    }
  });

  it("all scenarios should have required fields", () => {
    for (const category of categories) {
      for (const scenario of category.scenarios) {
        expect(scenario.id).toBeTruthy();
        expect(scenario.title).toBeTruthy();
        expect(scenario.description).toBeTruthy();
        expect(scenario.template).toBeTruthy();
        expect(Array.isArray(scenario.placeholders)).toBe(true);
      }
    }
  });

  it("all placeholders should have key and label", () => {
    for (const category of categories) {
      for (const scenario of category.scenarios) {
        for (const ph of scenario.placeholders) {
          expect(ph.key).toBeTruthy();
          expect(ph.label).toBeTruthy();
        }
      }
    }
  });

  it("all templates should contain their placeholders as [KEY] tokens", () => {
    for (const category of categories) {
      for (const scenario of category.scenarios) {
        for (const ph of scenario.placeholders) {
          expect(scenario.template).toContain(`[${ph.key}]`);
        }
      }
    }
  });

  it("all scenario IDs should be unique within their category", () => {
    for (const category of categories) {
      const ids = category.scenarios.map((s) => s.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    }
  });

  it("Inkasso category should have at least 15 scenarios", () => {
    const inkasso = categories.find((c) => c.id === "inkasso");
    expect(inkasso!.scenarios.length).toBeGreaterThanOrEqual(15);
  });

  it("Kronofogden category should have at least 8 scenarios", () => {
    const kronofogden = categories.find((c) => c.id === "kronofogden");
    expect(kronofogden!.scenarios.length).toBeGreaterThanOrEqual(8);
  });

  it("all UI text should be in Swedish (no English titles)", () => {
    for (const category of categories) {
      // Category titles should be Swedish terms
      expect(["Skatteverket", "Försäkringskassan", "Migrationsverket", "Inkasso", "Kronofogden", "Arbetsförmedlingen", "Socialstyrelsen", "Polisen", "Domstol", "Boverkets"]).toContain(category.title);
      
      for (const scenario of category.scenarios) {
        // Templates should contain Swedish greetings
        expect(scenario.template).toContain("Hej");
        // Templates should contain Swedish closings
        const hasSwedishClosing =
          scenario.template.includes("Med vänlig hälsning") ||
          scenario.template.includes("Vänliga hälsningar");
        expect(hasSwedishClosing).toBe(true);
      }
    }
  });

  it("template placeholder replacement should work correctly", () => {
    const scenario = categories[0].scenarios[0];
    let text = scenario.template;
    const values: Record<string, string> = {
      "DITT NAMN": "Anna Svensson",
      "PERSONNUMMER": "199001011234",
      "ÄRENDENUMMER": "INK-2026-001",
    };
    for (const ph of scenario.placeholders) {
      const val = values[ph.key] || `[${ph.key}]`;
      text = text.replace(new RegExp(`\\[${ph.key}\\]`, "g"), val);
    }
    expect(text).toContain("Anna Svensson");
    expect(text).toContain("199001011234");
    expect(text).toContain("INK-2026-001");
    expect(text).not.toContain("[DITT NAMN]");
    expect(text).not.toContain("[PERSONNUMMER]");
    expect(text).not.toContain("[ÄRENDENUMMER]");
  });
});
