"use strict";

process.on("uncaughtException", (err) => {
  console.error("[CRASH] Uncaught exception:", err);
});
process.on("unhandledRejection", (reason) => {
  console.error("[CRASH] Unhandled rejection:", reason);
});

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const { GoogleGenAI } = require("@google/genai");
const Stripe = require("stripe");
const path = require("path");

// ── ENV ────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "svardirekt-secret-change-me-in-prod";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || "";
const STRIPE_PRICE_ID = process.env.STRIPE_PRICE_ID || "";
const OWNER_EMAIL = "charteks1@gmail.com";
const AI_DAILY_LIMIT = 10;       // premium users: per day
const FREE_LETTER_LIMIT = 3;     // free users: total ever (anti-abuse)

// ── DATABASE ───────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, "data.db");
const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    device_id TEXT,
    is_premium INTEGER DEFAULT 0,
    subscription_status TEXT DEFAULT 'none',
    current_period_end INTEGER,
    stripe_customer_id TEXT,
    free_letters_used INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS device_registry (
    device_id TEXT PRIMARY KEY,
    first_registered INTEGER NOT NULL,
    account_count INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS ai_usage (
    user_id TEXT NOT NULL,
    date TEXT NOT NULL,
    count INTEGER DEFAULT 0,
    PRIMARY KEY (user_id, date)
  );
`);

// ── HELPERS ────────────────────────────────────────────────────────
function genId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "30d" });
}

function verifyToken(token) {
  return jwt.verify(token, JWT_SECRET);
}

function toPublicUser(u) {
  const isOwner = u.email === OWNER_EMAIL;
  const isPremium = isOwner || !!u.is_premium;
  const freeLettersUsed = u.free_letters_used || 0;
  const freeLettersRemaining = isPremium ? null : Math.max(0, FREE_LETTER_LIMIT - freeLettersUsed);
  return {
    id: u.id,
    email: u.email,
    createdAt: u.created_at,
    isOwner,
    isPremium,
    subscriptionStatus: isOwner ? "active" : (u.subscription_status || "none"),
    trialEndsAt: null,
    currentPeriodEnd: u.current_period_end || null,
    stripeCustomerId: u.stripe_customer_id || null,
    freeLettersRemaining,
  };
}

function getUserById(id) {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id);
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Autentisering krävs." });
  try {
    req.user = verifyToken(token);
    next();
  } catch {
    return res.status(401).json({ error: "Ogiltig token." });
  }
}

// ── STRIPE ─────────────────────────────────────────────────────────
const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" }) : null;

// ── GEMINI ─────────────────────────────────────────────────────────
const ai = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;

// ── APP ────────────────────────────────────────────────────────────
const app = express();

app.use(cors({ origin: "*" }));
app.use("/api/subscription/webhook", express.raw({ type: "application/json" }));
app.use(express.json());

// ── HEALTH ─────────────────────────────────────────────────────────
app.get("/api/test", (_req, res) => res.json({ ok: true, ts: Date.now() }));
app.get("/healthz", (_req, res) => res.json({ status: "ok" }));

// ── AUTH ───────────────────────────────────────────────────────────
app.post("/api/auth/register", async (req, res) => {
  try {
    const { email, password, deviceId } = req.body || {};
    if (!email?.trim() || !password?.trim())
      return res.status(400).json({ error: "E-post och lösenord krävs." });
    if (password.length < 6)
      return res.status(400).json({ error: "Lösenordet måste vara minst 6 tecken." });

    const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email.toLowerCase().trim());
    if (existing) return res.status(409).json({ error: "E-postadressen används redan." });

    // Device abuse check
    let startFreeLetters = FREE_LETTER_LIMIT;
    if (deviceId) {
      const deviceRecord = db.prepare("SELECT * FROM device_registry WHERE device_id = ?").get(deviceId);
      if (deviceRecord) {
        // Device already used a free trial before — give 0 free letters
        startFreeLetters = 0;
        db.prepare("UPDATE device_registry SET account_count = account_count + 1 WHERE device_id = ?").run(deviceId);
      } else {
        db.prepare("INSERT INTO device_registry (device_id, first_registered, account_count) VALUES (?, ?, 1)").run(deviceId, Date.now());
      }
    }

    const hash = await bcrypt.hash(password, 10);
    const id = genId();
    const now = Date.now();

    // free_letters_used = FREE_LETTER_LIMIT - startFreeLetters
    // so if startFreeLetters=0, free_letters_used starts at FREE_LETTER_LIMIT (= no free letters)
    const initialUsed = FREE_LETTER_LIMIT - startFreeLetters;

    db.prepare(
      "INSERT INTO users (id, email, password_hash, created_at, device_id, subscription_status, free_letters_used) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(id, email.toLowerCase().trim(), hash, now, deviceId || null, "none", initialUsed);

    const user = getUserById(id);
    const token = signToken({ sub: id, email: user.email });
    return res.json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/register]", err);
    return res.status(500).json({ error: "Ett fel uppstod. Försök igen." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email?.trim() || !password?.trim())
      return res.status(400).json({ error: "E-post och lösenord krävs." });

    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email.toLowerCase().trim());
    if (!user) return res.status(401).json({ error: "Fel e-post eller lösenord." });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Fel e-post eller lösenord." });

    const token = signToken({ sub: user.id, email: user.email });
    return res.json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/login]", err);
    return res.status(500).json({ error: "Ett fel uppstod. Försök igen." });
  }
});

app.get("/api/auth/me", authMiddleware, (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });
    return res.json({ user: toPublicUser(user) });
  } catch (err) {
    console.error("[auth/me]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

app.post("/api/auth/change-password", authMiddleware, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body || {};
    if (!oldPassword || !newPassword)
      return res.status(400).json({ error: "Gamla och nya lösenordet krävs." });
    if (newPassword.length < 6)
      return res.status(400).json({ error: "Nytt lösenord måste vara minst 6 tecken." });

    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    const ok = await bcrypt.compare(oldPassword, user.password_hash);
    if (!ok) return res.status(401).json({ error: "Fel gammalt lösenord." });

    const hash = await bcrypt.hash(newPassword, 10);
    db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, user.id);
    return res.json({ ok: true });
  } catch (err) {
    console.error("[auth/change-password]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

app.delete("/api/auth/account", authMiddleware, (req, res) => {
  try {
    db.prepare("DELETE FROM users WHERE id = ?").run(req.user.sub);
    db.prepare("DELETE FROM ai_usage WHERE user_id = ?").run(req.user.sub);
    return res.json({ ok: true });
  } catch (err) {
    console.error("[auth/account DELETE]", err);
    return res.status(500).json({ error: "Ett fel uppstod." });
  }
});

// ── SUBSCRIPTION ───────────────────────────────────────────────────
app.post("/api/subscription/checkout", authMiddleware, async (req, res) => {
  try {
    if (!stripe || !STRIPE_PRICE_ID)
      return res.status(503).json({ error: "Betalningar är inte konfigurerade." });

    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    const { successUrl, cancelUrl } = req.body || {};

    let customerId = user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({ email: user.email });
      customerId = customer.id;
      db.prepare("UPDATE users SET stripe_customer_id = ? WHERE id = ?").run(customerId, user.id);
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: "subscription",
      line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
      success_url: successUrl || "https://svardirekt.site",
      cancel_url: cancelUrl || "https://svardirekt.site",
      payment_method_collection: "always",
    });

    return res.json({ url: session.url, sessionId: session.id });
  } catch (err) {
    console.error("[subscription/checkout]", err);
    return res.status(500).json({ error: "Kunde inte skapa betalningssession." });
  }
});

app.post("/api/subscription/portal", authMiddleware, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ error: "Betalningar är inte konfigurerade." });
    const user = getUserById(req.user.sub);
    if (!user?.stripe_customer_id)
      return res.status(400).json({ error: "Ingen prenumeration hittades." });

    const { returnUrl } = req.body || {};
    const session = await stripe.billingPortal.sessions.create({
      customer: user.stripe_customer_id,
      return_url: returnUrl || "https://svardirekt.site",
    });
    return res.json({ url: session.url });
  } catch (err) {
    console.error("[subscription/portal]", err);
    return res.status(500).json({ error: "Kunde inte öppna kundportalen." });
  }
});

app.post("/api/subscription/cancel", authMiddleware, async (req, res) => {
  try {
    if (!stripe) return res.status(503).json({ error: "Betalningar är inte konfigurerade." });
    const user = getUserById(req.user.sub);
    if (!user?.stripe_customer_id)
      return res.status(400).json({ error: "Ingen prenumeration hittades." });

    const subs = await stripe.subscriptions.list({ customer: user.stripe_customer_id, limit: 1 });
    if (subs.data.length > 0) {
      await stripe.subscriptions.update(subs.data[0].id, { cancel_at_period_end: true });
    }
    db.prepare("UPDATE users SET subscription_status = 'canceling' WHERE id = ?").run(user.id);
    return res.json({ user: toPublicUser(getUserById(user.id)) });
  } catch (err) {
    console.error("[subscription/cancel]", err);
    return res.status(500).json({ error: "Kunde inte avsluta prenumerationen." });
  }
});

app.post("/api/subscription/refresh", authMiddleware, async (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(404).json({ error: "Användaren hittades inte." });

    if (stripe && user.stripe_customer_id) {
      const subs = await stripe.subscriptions.list({ customer: user.stripe_customer_id, status: "all", limit: 1 });
      if (subs.data.length > 0) {
        const sub = subs.data[0];
        const isPremium = (sub.status === "active" || sub.status === "trialing") ? 1 : 0;
        db.prepare(
          "UPDATE users SET is_premium = ?, subscription_status = ?, current_period_end = ? WHERE id = ?"
        ).run(isPremium, sub.status, sub.current_period_end * 1000, user.id);
      }
    }
    return res.json({ user: toPublicUser(getUserById(user.id)) });
  } catch (err) {
    console.error("[subscription/refresh]", err);
    return res.status(500).json({ error: "Kunde inte uppdatera prenumerationen." });
  }
});

app.post("/api/subscription/webhook", (req, res) => {
  if (!stripe || !STRIPE_WEBHOOK_SECRET) return res.json({ received: true });
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook error: ${err.message}`);
  }
  try {
    const sub = event.data.object;
    const customerId = sub.customer;
    if (!customerId) return res.json({ received: true });
    const user = db.prepare("SELECT * FROM users WHERE stripe_customer_id = ?").get(customerId);
    if (!user) return res.json({ received: true });

    if (["customer.subscription.updated", "customer.subscription.created"].includes(event.type)) {
      const isPremium = (sub.status === "active" || sub.status === "trialing") ? 1 : 0;
      db.prepare(
        "UPDATE users SET is_premium = ?, subscription_status = ?, current_period_end = ? WHERE id = ?"
      ).run(isPremium, sub.status, (sub.current_period_end || 0) * 1000, user.id);
    } else if (event.type === "customer.subscription.deleted") {
      db.prepare(
        "UPDATE users SET is_premium = 0, subscription_status = 'canceled', current_period_end = NULL WHERE id = ?"
      ).run(user.id);
    }
  } catch (err) {
    console.error("[webhook]", err);
  }
  return res.json({ received: true });
});

// ── AI ─────────────────────────────────────────────────────────────
app.post("/api/ai/ask", authMiddleware, async (req, res) => {
  try {
    const user = getUserById(req.user.sub);
    if (!user) return res.status(401).json({ error: "Inte autentiserad." });

    const isOwner = user.email === OWNER_EMAIL;
    const isPremium = isOwner || !!user.is_premium;

    if (!isPremium) {
      // Free user — check lifetime letter limit
      const freeUsed = user.free_letters_used || 0;
      if (freeUsed >= FREE_LETTER_LIMIT) {
        return res.status(402).json({
          error: `Du har använt dina ${FREE_LETTER_LIMIT} gratisbrev. Prenumerera för obegränsad åtkomst.`,
          code: "PREMIUM_REQUIRED",
        });
      }
    } else if (!isOwner) {
      // Premium user — check daily limit
      const today = todayStr();
      const usage = db.prepare("SELECT count FROM ai_usage WHERE user_id = ? AND date = ?").get(user.id, today);
      const count = usage ? usage.count : 0;
      if (count >= AI_DAILY_LIMIT) {
        return res.status(429).json({
          error: `Du har använt alla ${AI_DAILY_LIMIT} genereringar idag — återställs imorgon.`,
        });
      }
    }

    const { message } = req.body || {};
    if (!message?.trim()) return res.status(400).json({ error: "Meddelande saknas." });
    if (!ai) return res.status(503).json({ error: "AI-tjänsten är inte konfigurerad." });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ role: "user", parts: [{ text: message }] }],
      config: { maxOutputTokens: 1500, temperature: 0.3 },
    });

    const reply = response.text?.trim();
    if (!reply) return res.status(500).json({ error: "Inget svar från AI. Försök igen." });

    // Update usage counters
    if (isOwner) {
      // No limits for owner
    } else if (isPremium) {
      const today = todayStr();
      const usage = db.prepare("SELECT count FROM ai_usage WHERE user_id = ? AND date = ?").get(user.id, today);
      if (usage) {
        db.prepare("UPDATE ai_usage SET count = count + 1 WHERE user_id = ? AND date = ?").run(user.id, today);
      } else {
        db.prepare("INSERT INTO ai_usage (user_id, date, count) VALUES (?, ?, 1)").run(user.id, today);
      }
      const newCount = (usage ? usage.count : 0) + 1;
      return res.json({ reply, remaining: Math.max(0, AI_DAILY_LIMIT - newCount) });
    } else {
      // Free user
      const newUsed = (user.free_letters_used || 0) + 1;
      db.prepare("UPDATE users SET free_letters_used = ? WHERE id = ?").run(newUsed, user.id);
      return res.json({ reply, remaining: Math.max(0, FREE_LETTER_LIMIT - newUsed) });
    }

    return res.json({ reply, remaining: 999 });
  } catch (err) {
    console.error("[ai/ask]", err);
    return res.status(503).json({ error: "AI-tjänsten är tillfälligt otillgänglig. Försök igen senare." });
  }
});

// ── START ──────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`[Svar Direkt] Server running on port ${PORT}`);
  console.log(`[Svar Direkt] Free letters per new device: ${FREE_LETTER_LIMIT}`);
  console.log(`[Svar Direkt] Premium daily limit: ${AI_DAILY_LIMIT}`);
  console.log(`[Svar Direkt] Gemini AI: ${ai ? "OK" : "NOT CONFIGURED"}`);
  console.log(`[Svar Direkt] Stripe: ${stripe ? "OK" : "NOT CONFIGURED"}`);
});
