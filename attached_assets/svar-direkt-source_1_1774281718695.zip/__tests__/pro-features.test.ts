import { describe, it, expect, beforeEach, vi } from 'vitest';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  Favorite,
  CopyHistoryItem,
  Comment,
} from '../hooks/use-pro-features-v2';

// Mock AsyncStorage
vi.mock('@react-native-async-storage/async-storage', () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
  },
}));

// Mock React Native Share
vi.mock('react-native', () => ({
  Share: {
    share: vi.fn(),
  },
  Alert: {
    alert: vi.fn(),
  },
  Platform: {
    OS: 'ios',
  },
}));

describe('Pro Features - Search & Filter', () => {
  it('should filter templates by title', () => {
    const templates = [
      { id: '1', title: 'Begäran om omprövning', description: 'Request review', content: 'Please review' },
      { id: '2', title: 'Komplettering av uppgifter', description: 'Complete info', content: 'Add details' },
    ];

    const query = 'begäran';
    const filtered = templates.filter(t =>
      t.title.toLowerCase().includes(query) ||
      t.description.toLowerCase().includes(query) ||
      t.content.toLowerCase().includes(query)
    );

    expect(filtered).toHaveLength(1);
    expect(filtered[0].title).toContain('Begäran');
  });

  it('should return all templates when search is empty', () => {
    const templates = [
      { id: '1', title: 'Template 1', description: 'Desc 1', content: 'Content 1' },
      { id: '2', title: 'Template 2', description: 'Desc 2', content: 'Content 2' },
    ];

    const query = '';
    const filtered = query.trim() ? templates.filter(t =>
      t.title.toLowerCase().includes(query.toLowerCase())
    ) : templates;

    expect(filtered).toHaveLength(2);
  });

  it('should handle case-insensitive search', () => {
    const templates = [
      { id: '1', title: 'BEGÄRAN', description: 'Request', content: 'Content' },
      { id: '2', title: 'Komplettering', description: 'Complete', content: 'Content' },
    ];

    const query = 'begäran';
    const filtered = templates.filter(t =>
      t.title.toLowerCase().includes(query.toLowerCase())
    );

    expect(filtered).toHaveLength(1);
    expect(filtered[0].title.toLowerCase()).toContain('begäran');
  });

  it('should search in description and content', () => {
    const templates = [
      { id: '1', title: 'Template 1', description: 'Important request', content: 'Content 1' },
      { id: '2', title: 'Template 2', description: 'Desc 2', content: 'Another important thing' },
    ];

    const query = 'important';
    const filtered = templates.filter(t =>
      t.title.toLowerCase().includes(query) ||
      t.description.toLowerCase().includes(query) ||
      t.content.toLowerCase().includes(query)
    );

    expect(filtered).toHaveLength(2);
  });
});

describe('Pro Features - Favorites', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should create favorite object', () => {
    const favorite: Favorite = {
      categoryId: 'skatteverket',
      templateId: 'template-1',
      addedAt: Date.now(),
    };

    expect(favorite).toBeDefined();
    expect(favorite.categoryId).toBe('skatteverket');
    expect(favorite.templateId).toBe('template-1');
    expect(favorite.addedAt).toBeGreaterThan(0);
  });

  it('should add favorite to list', () => {
    const favorites: Favorite[] = [];
    const newFavorite: Favorite = {
      categoryId: 'skatteverket',
      templateId: 'template-1',
      addedAt: Date.now(),
    };

    const updated = [...favorites, newFavorite];
    expect(updated).toHaveLength(1);
    expect(updated[0].templateId).toBe('template-1');
  });

  it('should remove favorite', () => {
    const favorites: Favorite[] = [
      { categoryId: 'skatteverket', templateId: 'template-1', addedAt: Date.now() },
      { categoryId: 'skatteverket', templateId: 'template-2', addedAt: Date.now() },
    ];

    const filtered = favorites.filter(f => f.templateId !== 'template-1');
    expect(filtered).toHaveLength(1);
    expect(filtered[0].templateId).toBe('template-2');
  });

  it('should check if template is favorite', () => {
    const favorites: Favorite[] = [
      { categoryId: 'skatteverket', templateId: 'template-1', addedAt: Date.now() },
    ];

    const isFavorite = favorites.some(f => f.templateId === 'template-1');
    expect(isFavorite).toBe(true);

    const isNotFavorite = favorites.some(f => f.templateId === 'template-2');
    expect(isNotFavorite).toBe(false);
  });

  it('should prevent duplicate favorites', () => {
    const favorites: Favorite[] = [
      { categoryId: 'skatteverket', templateId: 'template-1', addedAt: Date.now() },
    ];

    const isDuplicate = favorites.some(f => f.templateId === 'template-1');
    expect(isDuplicate).toBe(true);
  });
});

describe('Pro Features - Copy History', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should create history item', () => {
    const historyItem: CopyHistoryItem = {
      templateId: 'template-1',
      categoryId: 'skatteverket',
      content: 'Begäran om omprövning av beslut',
      copiedAt: Date.now(),
      title: 'Begäran om omprövning',
    };

    expect(historyItem).toBeDefined();
    expect(historyItem.templateId).toBe('template-1');
    expect(historyItem.content).toContain('Begäran');
  });

  it('should add item to history', () => {
    const history: CopyHistoryItem[] = [];
    const item: CopyHistoryItem = {
      templateId: 'template-1',
      categoryId: 'skatteverket',
      content: 'Content',
      copiedAt: Date.now(),
      title: 'Template',
    };

    const updated = [item, ...history];
    expect(updated).toHaveLength(1);
    expect(updated[0].templateId).toBe('template-1');
  });

  it('should keep only last 10 items', () => {
    const history: CopyHistoryItem[] = Array.from({ length: 11 }, (_, i) => ({
      templateId: `template-${i}`,
      categoryId: 'skatteverket',
      content: `Content ${i}`,
      copiedAt: Date.now() - i * 1000,
      title: `Template ${i}`,
    }));

    const limited = history.slice(0, 10);
    expect(limited).toHaveLength(10);
  });

  it('should clear history', () => {
    const history: CopyHistoryItem[] = [
      {
        templateId: 'template-1',
        categoryId: 'skatteverket',
        content: 'Content',
        copiedAt: Date.now(),
        title: 'Template',
      },
    ];

    const cleared: CopyHistoryItem[] = [];
    expect(cleared).toHaveLength(0);
  });

  it('should preserve order (newest first)', () => {
    const now = Date.now();
    const history: CopyHistoryItem[] = [
      {
        templateId: 'template-1',
        categoryId: 'skatteverket',
        content: 'Content 1',
        copiedAt: now - 2000,
        title: 'Template 1',
      },
      {
        templateId: 'template-2',
        categoryId: 'skatteverket',
        content: 'Content 2',
        copiedAt: now - 1000,
        title: 'Template 2',
      },
      {
        templateId: 'template-3',
        categoryId: 'skatteverket',
        content: 'Content 3',
        copiedAt: now,
        title: 'Template 3',
      },
    ];

    const sorted = history.sort((a, b) => b.copiedAt - a.copiedAt);
    expect(sorted[0].templateId).toBe('template-3');
    expect(sorted[2].templateId).toBe('template-1');
  });
});

describe('Pro Features - Text Formatting', () => {
  it('should apply bold formatting', () => {
    const text = 'This is important';
    const selectedText = 'important';
    const formatted = text.replace(selectedText, `**${selectedText}**`);
    expect(formatted).toBe('This is **important**');
  });

  it('should apply italic formatting', () => {
    const text = 'This is emphasized';
    const selectedText = 'emphasized';
    const formatted = text.replace(selectedText, `*${selectedText}*`);
    expect(formatted).toBe('This is *emphasized*');
  });

  it('should apply underline formatting', () => {
    const text = 'This is underlined';
    const selectedText = 'underlined';
    const formatted = text.replace(selectedText, `__${selectedText}__`);
    expect(formatted).toBe('This is __underlined__');
  });

  it('should add bullet point', () => {
    const text = 'First point';
    const withBullet = text + '\n• ';
    expect(withBullet).toContain('• ');
    expect(withBullet).toContain('First point');
  });

  it('should add numbered point', () => {
    const text = 'First point\n1. Second point';
    const lines = text.split('\n');
    const lastNumber = lines.filter(l => /^\d+\./.test(l)).length;
    const withNumber = text + `\n${lastNumber + 1}. `;
    expect(withNumber).toContain('2. ');
  });

  it('should handle multiple formatting', () => {
    let text = 'Important emphasized underlined';
    text = text.replace('Important', '**Important**');
    text = text.replace('emphasized', '*emphasized*');
    text = text.replace('underlined', '__underlined__');
    expect(text).toContain('**Important**');
    expect(text).toContain('*emphasized*');
    expect(text).toContain('__underlined__');
  });
});

describe('Pro Features - Comments', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should create comment object', () => {
    const comment: Comment = {
      id: `${Date.now()}`,
      templateId: 'template-1',
      author: 'User',
      text: 'Great template!',
      createdAt: Date.now(),
      likes: 0,
    };

    expect(comment).toBeDefined();
    expect(comment.templateId).toBe('template-1');
    expect(comment.text).toBe('Great template!');
    expect(comment.likes).toBe(0);
  });

  it('should add comment to template', () => {
    const comments: { [key: string]: Comment[] } = {};
    const newComment: Comment = {
      id: '1',
      templateId: 'template-1',
      author: 'User',
      text: 'Good',
      createdAt: Date.now(),
      likes: 0,
    };

    const updated = {
      ...comments,
      'template-1': [...(comments['template-1'] || []), newComment],
    };

    expect(updated['template-1']).toHaveLength(1);
    expect(updated['template-1'][0].text).toBe('Good');
  });

  it('should get comments for template sorted by newest first', () => {
    const now = Date.now();
    const comments: { [key: string]: Comment[] } = {
      'template-1': [
        {
          id: '1',
          templateId: 'template-1',
          author: 'User1',
          text: 'Good',
          createdAt: now - 1000,
          likes: 5,
        },
        {
          id: '2',
          templateId: 'template-1',
          author: 'User2',
          text: 'Excellent',
          createdAt: now,
          likes: 3,
        },
      ],
    };

    const templateComments = (comments['template-1'] || []).sort(
      (a, b) => b.createdAt - a.createdAt
    );

    expect(templateComments).toHaveLength(2);
    expect(templateComments[0].text).toBe('Excellent');
    expect(templateComments[1].text).toBe('Good');
  });

  it('should like comment', () => {
    const comments: { [key: string]: Comment[] } = {
      'template-1': [
        {
          id: '1',
          templateId: 'template-1',
          author: 'User',
          text: 'Good',
          createdAt: Date.now(),
          likes: 0,
        },
      ],
    };

    const updated = {
      ...comments,
      'template-1': (comments['template-1'] || []).map(c =>
        c.id === '1' ? { ...c, likes: c.likes + 1 } : c
      ),
    };

    expect(updated['template-1'][0].likes).toBe(1);
  });

  it('should handle anonymous comments', () => {
    const comment: Comment = {
      id: `${Date.now()}`,
      templateId: 'template-1',
      author: 'Anonym',
      text: 'Anonymous feedback',
      createdAt: Date.now(),
      likes: 0,
    };

    expect(comment.author).toBe('Anonym');
  });

  it('should increment likes multiple times', () => {
    const comments: { [key: string]: Comment[] } = {
      'template-1': [
        {
          id: '1',
          templateId: 'template-1',
          author: 'User',
          text: 'Good',
          createdAt: Date.now(),
          likes: 0,
        },
      ],
    };

    let updated = comments;
    for (let i = 0; i < 3; i++) {
      updated = {
        ...updated,
        'template-1': (updated['template-1'] || []).map(c =>
          c.id === '1' ? { ...c, likes: c.likes + 1 } : c
        ),
      };
    }

    expect(updated['template-1'][0].likes).toBe(3);
  });
});

describe('Pro Features - Share Template', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should format share message correctly', () => {
    const title = 'Begäran om omprövning';
    const content = 'Jag begär omprövning av ert beslut...';
    const message = `Svar Direkt - ${title}\n\n${content}\n\nLadda ner appen: https://play.google.com/store/apps/details?id=space.manus.svar.direkt`;

    expect(message).toContain('Svar Direkt');
    expect(message).toContain(title);
    expect(message).toContain(content);
    expect(message).toContain('play.google.com');
  });

  it('should include app store link', () => {
    const message = `Svar Direkt - Template\n\nContent\n\nLadda ner appen: https://play.google.com/store/apps/details?id=space.manus.svar.direkt`;
    expect(message).toContain('https://play.google.com/store/apps/details?id=space.manus.svar.direkt');
  });

  it('should handle special characters in title', () => {
    const title = 'Begäran om omprövning - Skatteverket';
    const content = 'Content';
    const message = `Svar Direkt - ${title}\n\n${content}\n\nLadda ner appen: https://play.google.com/store/apps/details?id=space.manus.svar.direkt`;

    expect(message).toContain('Skatteverket');
    expect(message).toContain('omprövning');
  });

  it('should handle long content', () => {
    const title = 'Template';
    const content = 'A'.repeat(500);
    const message = `Svar Direkt - ${title}\n\n${content}\n\nLadda ner appen: https://play.google.com/store/apps/details?id=space.manus.svar.direkt`;

    expect(message.length).toBeGreaterThan(500);
    expect(message).toContain('Svar Direkt');
  });
});

describe('Pro Features Integration', () => {
  it('should handle multiple Pro features together', () => {
    const templates = [
      { id: '1', title: 'Template 1', description: 'Desc 1', content: 'Content 1' },
      { id: '2', title: 'Template 2', description: 'Desc 2', content: 'Content 2' },
    ];

    const favorites: Favorite[] = [
      { categoryId: 'skatteverket', templateId: '1', addedAt: Date.now() },
    ];

    const history: CopyHistoryItem[] = [
      {
        templateId: '1',
        categoryId: 'skatteverket',
        content: 'Content 1',
        copiedAt: Date.now(),
        title: 'Template 1',
      },
    ];

    const comments: { [key: string]: Comment[] } = {
      '1': [
        {
          id: '1',
          templateId: '1',
          author: 'User',
          text: 'Great',
          createdAt: Date.now(),
          likes: 5,
        },
      ],
    };

    expect(templates).toHaveLength(2);
    expect(favorites).toHaveLength(1);
    expect(history).toHaveLength(1);
    expect(comments['1']).toHaveLength(1);
  });

  it('should maintain data consistency across features', () => {
    const templateId = 'template-1';
    const categoryId = 'skatteverket';

    const favorite: Favorite = { categoryId, templateId, addedAt: Date.now() };
    const historyItem: CopyHistoryItem = {
      templateId,
      categoryId,
      content: 'Content',
      copiedAt: Date.now(),
      title: 'Title',
    };
    const comment: Comment = {
      id: '1',
      templateId,
      author: 'User',
      text: 'Comment',
      createdAt: Date.now(),
      likes: 0,
    };

    expect(favorite.templateId).toBe(templateId);
    expect(historyItem.templateId).toBe(templateId);
    expect(comment.templateId).toBe(templateId);
  });

  it('should work with all 10 categories', () => {
    const categories = [
      'skatteverket',
      'forsakringskassan',
      'migrationsverket',
      'inkasso',
      'kronofogden',
      'arbetsformedlingen',
      'socialstyrelsen',
      'polisen',
      'domstol',
      'boverkets',
    ];

    const favorites: Favorite[] = categories.map((cat, i) => ({
      categoryId: cat,
      templateId: `template-${i}`,
      addedAt: Date.now(),
    }));

    expect(favorites).toHaveLength(10);
    expect(favorites.map(f => f.categoryId)).toEqual(categories);
  });
});
