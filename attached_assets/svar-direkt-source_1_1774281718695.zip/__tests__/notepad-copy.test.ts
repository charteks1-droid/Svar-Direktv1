import { describe, it, expect, beforeEach, vi } from "vitest";
import * as Clipboard from "expo-clipboard";

// Mock Clipboard
vi.mock("expo-clipboard", () => ({
  setString: vi.fn(),
  getString: vi.fn(),
}));

describe("Notepad Copy Functionality", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should copy note text with user info to clipboard", async () => {
    const noteText = "This is my test note";
    const fullName = "John Doe";
    const personnummer = "123456-7890";

    const textToCopy = `${noteText}\n\n---\nNamn: ${fullName}\nPersonnummer: ${personnummer}`;

    await Clipboard.setString(textToCopy);

    expect(Clipboard.setString).toHaveBeenCalledWith(textToCopy);
  });

  it("should format copied text correctly with separator", async () => {
    const noteText = "Important note content";
    const fullName = "Anna Svensson";
    const personnummer = "198512345678";

    const textToCopy = `${noteText}\n\n---\nNamn: ${fullName}\nPersonnummer: ${personnummer}`;

    await Clipboard.setString(textToCopy);

    expect(Clipboard.setString).toHaveBeenCalledWith(
      expect.stringContaining("Important note content")
    );
    expect(Clipboard.setString).toHaveBeenCalledWith(
      expect.stringContaining("Namn: Anna Svensson")
    );
    expect(Clipboard.setString).toHaveBeenCalledWith(
      expect.stringContaining("Personnummer: 198512345678")
    );
  });

  it("should handle empty note text", async () => {
    const noteText = "";
    const fullName = "Test User";
    const personnummer = "999999-9999";

    const textToCopy = `${noteText}\n\n---\nNamn: ${fullName}\nPersonnummer: ${personnummer}`;

    await Clipboard.setString(textToCopy);

    expect(Clipboard.setString).toHaveBeenCalledWith(textToCopy);
  });

  it("should handle special characters in note", async () => {
    const noteText = "Note with åäö and special chars: !@#$%";
    const fullName = "Åsa Öberg";
    const personnummer = "123456-7890";

    const textToCopy = `${noteText}\n\n---\nNamn: ${fullName}\nPersonnummer: ${personnummer}`;

    await Clipboard.setString(textToCopy);

    expect(Clipboard.setString).toHaveBeenCalledWith(textToCopy);
  });

  it("should handle multiline note text", async () => {
    const noteText = "Line 1\nLine 2\nLine 3";
    const fullName = "Multi Line User";
    const personnummer = "111111-1111";

    const textToCopy = `${noteText}\n\n---\nNamn: ${fullName}\nPersonnummer: ${personnummer}`;

    await Clipboard.setString(textToCopy);

    expect(Clipboard.setString).toHaveBeenCalledWith(
      expect.stringContaining("Line 1\nLine 2\nLine 3")
    );
  });

  it("should include separator between note and user info", async () => {
    const noteText = "Test note";
    const fullName = "Test User";
    const personnummer = "123456-7890";

    const textToCopy = `${noteText}\n\n---\nNamn: ${fullName}\nPersonnummer: ${personnummer}`;

    await Clipboard.setString(textToCopy);

    const callArg = (Clipboard.setString as any).mock.calls[0][0];
    expect(callArg).toContain("\n\n---\n");
  });
});
