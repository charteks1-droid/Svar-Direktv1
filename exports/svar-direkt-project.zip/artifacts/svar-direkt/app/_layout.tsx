import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppProvider } from "@/contexts/AppContext";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerBackTitle: "Tillbaka" }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen
        name="reminders"
        options={{ title: "Påminnelser", headerBackTitle: "Tillbaka" }}
      />
      <Stack.Screen
        name="custom-templates"
        options={{ title: "Mina mallar", headerBackTitle: "Tillbaka" }}
      />
      <Stack.Screen
        name="history"
        options={{ title: "Historik", headerBackTitle: "Tillbaka" }}
      />
      <Stack.Screen
        name="quick-responses"
        options={{ title: "Snabba svar", headerBackTitle: "Tillbaka" }}
      />
      <Stack.Screen
        name="about"
        options={{ title: "Om appen", headerBackTitle: "Tillbaka" }}
      />
      <Stack.Screen
        name="template-detail"
        options={{ title: "Mall", headerBackTitle: "Tillbaka", presentation: "modal" }}
      />
      <Stack.Screen
        name="quick-solution"
        options={{ title: "Snabb lösning", headerBackTitle: "Tillbaka" }}
      />
      <Stack.Screen
        name="forsvar"
        options={{ title: "Försvara dig", headerBackTitle: "Tillbaka" }}
      />
      <Stack.Screen
        name="ai-compose"
        options={{ title: "AI-Assistent", headerShown: false }}
      />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <AppProvider>
            <GestureHandlerRootView style={{ flex: 1 }}>
              <KeyboardProvider>
                <RootLayoutNav />
              </KeyboardProvider>
            </GestureHandlerRootView>
          </AppProvider>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
