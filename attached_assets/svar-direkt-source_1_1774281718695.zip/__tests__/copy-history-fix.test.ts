import { describe, it, expect, beforeEach, vi } from "vitest";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Mock AsyncStorage
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
  },
}));

describe("Copy History Fix - Message Persistence", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should save copied message to history with correct structure", async () => {
    const messageText = "Test message for Skatteverket";
    const templateTitle = "Ansökan om avbetalningsplan";
    const categoryId = "skatteverket";

    const historyMessage = {
      id: Date.now().toString(),
      text: messageText,
      templateTitle,
      categoryId,
      timestamp: Date.now(),
      date: new Date().toLocaleDateString("sv-SE"),
    };

    const history = [historyMessage];

    await AsyncStorage.setItem(
      "svar_direkt_message_history",
      JSON.stringify(history)
    );

    expect(AsyncStorage.setItem).toHaveBeenCalledWith(
      "svar_direkt_message_history",
      expect.stringContaining(messageText)
    );
    expect(AsyncStorage.setItem).toHaveBeenCalledWith(
      "svar_direkt_message_history",
      expect.stringContaining(templateTitle)
    );
  });

  it("should prepend new message to existing history", async () => {
    const oldMessage = {
      id: "1",
      text: "Old message",
      templateTitle: "Old Template",
      categoryId: "old-category",
      timestamp: Date.now() - 1000,
      date: new Date(Date.now() - 1000).toLocaleDateString("sv-SE"),
    };

    const newMessage = {
      id: "2",
      text: "New message",
      templateTitle: "New Template",
      categoryId: "new-category",
      timestamp: Date.now(),
      date: new Date().toLocaleDateString("sv-SE"),
    };

    const updatedHistory = [newMessage, oldMessage];

    await AsyncStorage.setItem(
      "svar_direkt_message_history",
      JSON.stringify(updatedHistory)
    );

    expect(AsyncStorage.setItem).toHaveBeenCalledWith(
      "svar_direkt_message_history",
      expect.stringContaining("New message")
    );
  });

  it("should limit history to 100 items maximum", async () => {
    const history = Array.from({ length: 101 }, (_, i) => ({
      id: i.toString(),
      text: `Message ${i}`,
      templateTitle: `Template ${i}`,
      categoryId: "test",
      timestamp: Date.now() - i * 1000,
      date: new Date().toLocaleDateString("sv-SE"),
    }));

    // Simulate the MAX_HISTORY_ITEMS = 100 logic
    const limitedHistory = history.slice(0, 100);

    await AsyncStorage.setItem(
      "svar_direkt_message_history",
      JSON.stringify(limitedHistory)
    );

    expect(limitedHistory).toHaveLength(100);
    expect(AsyncStorage.setItem).toHaveBeenCalled();
  });

  it("should include all required fields in saved message", async () => {
    const message = {
      id: "test-id-123",
      text: "Complete message text",
      templateTitle: "Template Title",
      categoryId: "category-id",
      timestamp: 1234567890,
      date: "2026-03-02",
    };

    const history = [message];

    await AsyncStorage.setItem(
      "svar_direkt_message_history",
      JSON.stringify(history)
    );

    const callArg = (AsyncStorage.setItem as any).mock.calls[0][1];
    const parsed = JSON.parse(callArg);

    expect(parsed[0]).toHaveProperty("id");
    expect(parsed[0]).toHaveProperty("text");
    expect(parsed[0]).toHaveProperty("templateTitle");
    expect(parsed[0]).toHaveProperty("categoryId");
    expect(parsed[0]).toHaveProperty("timestamp");
    expect(parsed[0]).toHaveProperty("date");
  });

  it("should handle message with special Swedish characters", async () => {
    const messageText = "Jag ansöker om stöd för åtgärder gällande mina räkningar";
    const templateTitle = "Ansökan om ekonomisk hjälp";

    const message = {
      id: Date.now().toString(),
      text: messageText,
      templateTitle,
      categoryId: "socialstyrelsen",
      timestamp: Date.now(),
      date: new Date().toLocaleDateString("sv-SE"),
    };

    const history = [message];

    await AsyncStorage.setItem(
      "svar_direkt_message_history",
      JSON.stringify(history)
    );

    const callArg = (AsyncStorage.setItem as any).mock.calls[0][1];
    const parsed = JSON.parse(callArg);

    expect(parsed[0].text).toContain("åtgärder");
    expect(parsed[0].text).toContain("räkningar");
    expect(parsed[0].templateTitle).toContain("ekonomisk");
  });

  it("should handle empty message text gracefully", async () => {
    const message = {
      id: Date.now().toString(),
      text: "",
      templateTitle: "Empty Template",
      categoryId: "test",
      timestamp: Date.now(),
      date: new Date().toLocaleDateString("sv-SE"),
    };

    const history = [message];

    await AsyncStorage.setItem(
      "svar_direkt_message_history",
      JSON.stringify(history)
    );

    expect(AsyncStorage.setItem).toHaveBeenCalled();
    const callArg = (AsyncStorage.setItem as any).mock.calls[0][1];
    const parsed = JSON.parse(callArg);
    expect(parsed[0].text).toBe("");
  });

  it("should preserve message order with correct timestamps", async () => {
    const now = Date.now();
    const messages = [
      {
        id: "3",
        text: "Third message",
        templateTitle: "Template 3",
        categoryId: "cat3",
        timestamp: now,
        date: new Date(now).toLocaleDateString("sv-SE"),
      },
      {
        id: "2",
        text: "Second message",
        templateTitle: "Template 2",
        categoryId: "cat2",
        timestamp: now - 1000,
        date: new Date(now - 1000).toLocaleDateString("sv-SE"),
      },
      {
        id: "1",
        text: "First message",
        templateTitle: "Template 1",
        categoryId: "cat1",
        timestamp: now - 2000,
        date: new Date(now - 2000).toLocaleDateString("sv-SE"),
      },
    ];

    await AsyncStorage.setItem(
      "svar_direkt_message_history",
      JSON.stringify(messages)
    );

    const callArg = (AsyncStorage.setItem as any).mock.calls[0][1];
    const parsed = JSON.parse(callArg);

    expect(parsed[0].id).toBe("3");
    expect(parsed[1].id).toBe("2");
    expect(parsed[2].id).toBe("1");
  });
});
